function outt = inference_op(x)
global IA IC RE inc_prev inc_now N M ...
    demo_comp use_of_time DE DI epsilon T  INF_R


R0 = x(:,1);
eta = x(:,2);
zeta = x(:,3);

R0_b = R0;

outt = zeros(M,4);
RMSE = zeros(10,10,10,M);

for outid = 1:M
for x1 = 1:10
    R0(outid) = R0_b(outid) - inc_prev + inc_now*x1;
    for x2 = 1:10
        eta(outid) = 0 + 0.1*x2;
        for x3 = 1:10
            zeta(outid) = 0 + 0.1*x3;
            
sus = zeros(M,T);
sus0 = zeros(M,T);
sus1 = zeros(M,T);
sus2 = zeros(M,T);
sus3 = zeros(M,T);
sus4 = zeros(M,T);
sus5 = zeros(M,T);
sus6 = zeros(M,T);
sus7 = zeros(M,T);
sus8 = zeros(M,T);
exp = zeros(M,T);
exp0 = zeros(M,T);
exp1 = zeros(M,T);
exp2 = zeros(M,T);
exp3 = zeros(M,T);
exp4 = zeros(M,T);
exp5 = zeros(M,T);
exp6 = zeros(M,T);
exp7 = zeros(M,T);
exp8 = zeros(M,T);
inf_r = zeros(M,T);
inf_r0 = zeros(M,T);
inf_r1 = zeros(M,T);
inf_r2 = zeros(M,T);
inf_r3 = zeros(M,T);
inf_r4 = zeros(M,T);
inf_r5 = zeros(M,T);
inf_r6 = zeros(M,T);
inf_r7 = zeros(M,T);
inf_r8 = zeros(M,T);
inf_u = zeros(M,T);
inf_u0 = zeros(M,T);
inf_u1 = zeros(M,T);
inf_u2 = zeros(M,T);
inf_u3 = zeros(M,T);
inf_u4 = zeros(M,T);
inf_u5 = zeros(M,T);
inf_u6 = zeros(M,T);
inf_u7 = zeros(M,T);
inf_u8 = zeros(M,T);
inf = zeros(M,T);
inf0 = zeros(M,T);
inf1 = zeros(M,T);
inf2 = zeros(M,T);
inf3 = zeros(M,T);
inf4 = zeros(M,T);
inf5 = zeros(M,T);
inf6 = zeros(M,T);
inf7 = zeros(M,T);
inf8 = zeros(M,T);
rec = zeros(M,T);

% initialization
inf_r(:,1) = IC./N;
inf_u(:,1) = (1./eta - 1).*inf_r(:,1);
inf(:,1) = inf_r(:,1) + inf_u(:,1);
exp(:,1) = inf_r(:,1)./zeta;
rec(:,1) = RE./N; 
sus(:,1) = 1-inf(:,1)-exp(:,1)-rec(:,1);
% partition uniform
sus0(:,1) = sus(:,1).*demo_comp(:,1);
sus1(:,1) = sus(:,1).*demo_comp(:,2);
sus2(:,1) = sus(:,1).*demo_comp(:,3);
sus3(:,1) = sus(:,1).*demo_comp(:,4);
sus4(:,1) = sus(:,1).*demo_comp(:,5);
sus5(:,1) = sus(:,1).*demo_comp(:,6);
sus6(:,1) = sus(:,1).*demo_comp(:,7);
sus7(:,1) = sus(:,1).*demo_comp(:,8);
sus8(:,1) = sus(:,1).*demo_comp(:,9);
inf_r0(:,1) = inf_r(:,1).*demo_comp(:,1);
inf_r1(:,1) = inf_r(:,1).*demo_comp(:,2);
inf_r2(:,1) = inf_r(:,1).*demo_comp(:,3);
inf_r3(:,1) = inf_r(:,1).*demo_comp(:,4);
inf_r4(:,1) = inf_r(:,1).*demo_comp(:,5);
inf_r5(:,1) = inf_r(:,1).*demo_comp(:,6);
inf_r6(:,1) = inf_r(:,1).*demo_comp(:,7);
inf_r7(:,1) = inf_r(:,1).*demo_comp(:,8);
inf_r8(:,1) = inf_r(:,1).*demo_comp(:,9);
inf_u0(:,1) = inf_u(:,1).*demo_comp(:,1);
inf_u1(:,1) = inf_u(:,1).*demo_comp(:,2);
inf_u2(:,1) = inf_u(:,1).*demo_comp(:,3);
inf_u3(:,1) = inf_u(:,1).*demo_comp(:,4);
inf_u4(:,1) = inf_u(:,1).*demo_comp(:,5);
inf_u5(:,1) = inf_u(:,1).*demo_comp(:,6);
inf_u6(:,1) = inf_u(:,1).*demo_comp(:,7);
inf_u7(:,1) = inf_u(:,1).*demo_comp(:,8);
inf_u8(:,1) = inf_u(:,1).*demo_comp(:,9);
inf0(:,1) = inf(:,1).*demo_comp(:,1);
inf1(:,1) = inf(:,1).*demo_comp(:,2);
inf2(:,1) = inf(:,1).*demo_comp(:,3);
inf3(:,1) = inf(:,1).*demo_comp(:,4);
inf4(:,1) = inf(:,1).*demo_comp(:,5);
inf5(:,1) = inf(:,1).*demo_comp(:,6);
inf6(:,1) = inf(:,1).*demo_comp(:,7);
inf7(:,1) = inf(:,1).*demo_comp(:,8);
inf8(:,1) = inf(:,1).*demo_comp(:,9);
exp0(:,1) = exp(:,1).*demo_comp(:,1);
exp1(:,1) = exp(:,1).*demo_comp(:,2);
exp2(:,1) = exp(:,1).*demo_comp(:,3);
exp3(:,1) = exp(:,1).*demo_comp(:,4);
exp4(:,1) = exp(:,1).*demo_comp(:,5);
exp5(:,1) = exp(:,1).*demo_comp(:,6);
exp6(:,1) = exp(:,1).*demo_comp(:,7);
exp7(:,1) = exp(:,1).*demo_comp(:,8);
exp8(:,1) = exp(:,1).*demo_comp(:,9);

% seir
for t = 2:T 
    % integration
    i = outid;
    max_eig_uot = max(eig(use_of_time));
    q = R0(i)/max_eig_uot;
    R0_age = sum((use_of_time.*q),1);
    R00 = R0_age(1);
    R01 = R0_age(2);
    R02 = R0_age(3);
    R03 = R0_age(4);
    R04 = R0_age(5);
    R05 = R0_age(6);
    R06 = R0_age(7);
    R07 = R0_age(8);
    R08 = R07; % assume that 80+ has the same susceptibility as the 70-79
    % exposed
    d_exp0 = R00*(1/DI)*sus0(i,t-1)*inf_r(i,t-1)...
        + R00*(1/DI)/epsilon*sus0(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp0(i,t-1);
    d_exp1 = R01*(1/DI)*sus1(i,t-1)*inf_r(i,t-1)...
        + R01*(1/DI)/epsilon*sus1(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp1(i,t-1);
    d_exp2 = R02*(1/DI)*sus2(i,t-1)*inf_r(i,t-1)...
        + R02*(1/DI)/epsilon*sus2(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp2(i,t-1);
    d_exp3 = R03*(1/DI)*sus3(i,t-1)*inf_r(i,t-1)...
        + R03*(1/DI)/epsilon*sus3(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp3(i,t-1);
    d_exp4 = R04*(1/DI)*sus4(i,t-1)*inf_r(i,t-1)...
        + R04*(1/DI)/epsilon*sus4(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp4(i,t-1);
    d_exp5 = R05*(1/DI)*sus5(i,t-1)*inf_r(i,t-1)...
        + R05*(1/DI)/epsilon*sus5(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp5(i,t-1);
    d_exp6 = R06*(1/DI)*sus6(i,t-1)*inf_r(i,t-1)...
        + R06*(1/DI)/epsilon*sus6(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp6(i,t-1);
    d_exp7 = R07*(1/DI)*sus7(i,t-1)*inf_r(i,t-1)...
        + R07*(1/DI)/epsilon*sus7(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp7(i,t-1);
    d_exp8 = R08*(1/DI)*sus8(i,t-1)*inf_r(i,t-1)...
        + R08*(1/DI)/epsilon*sus8(i,t-1)*inf_u(i,t-1)...
        - (1/DE)*exp8(i,t-1);
    % infected and documented
    d_inf_r0 = eta(i)*(1/DE)*exp0(i,t-1)...
        - (1/DI)*inf_r0(i,t-1);
    d_inf_r1 = eta(i)*(1/DE)*exp1(i,t-1)...
        - (1/DI)*inf_r1(i,t-1);
    d_inf_r2 = eta(i)*(1/DE)*exp2(i,t-1)...
        - (1/DI)*inf_r2(i,t-1);
    d_inf_r3 = eta(i)*(1/DE)*exp3(i,t-1)...
        - (1/DI)*inf_r3(i,t-1);
    d_inf_r4 = eta(i)*(1/DE)*exp4(i,t-1)...
        - (1/DI)*inf_r4(i,t-1);
    d_inf_r5 = eta(i)*(1/DE)*exp5(i,t-1)...
            - (1/DI)*inf_r5(i,t-1);
    d_inf_r6 = eta(i)*(1/DE)*exp6(i,t-1)...
        - (1/DI)*inf_r6(i,t-1);
    d_inf_r7 = eta(i)*(1/DE)*exp7(i,t-1)...
        - (1/DI)*inf_r7(i,t-1);
    d_inf_r8 = eta(i)*(1/DE)*exp8(i,t-1)...
        - (1/DI)*inf_r8(i,t-1);
    % infected and undocumented
    d_inf_u0 = (1-eta(i))*(1/DE)*exp0(i,t-1)...
        - (1/DI)/epsilon*inf_u0(i,t-1);
    d_inf_u1 = (1-eta(i))*(1/DE)*exp1(i,t-1)...
        - (1/DI)/epsilon*inf_u1(i,t-1);
    d_inf_u2 = (1-eta(i))*(1/DE)*exp2(i,t-1)...
        - (1/DI)/epsilon*inf_u2(i,t-1);
    d_inf_u3 = (1-eta(i))*(1/DE)*exp3(i,t-1)...
        - (1/DI)/epsilon*inf_u3(i,t-1);
    d_inf_u4 = (1-eta(i))*(1/DE)*exp4(i,t-1)...
        - (1/DI)/epsilon*inf_u4(i,t-1);
    d_inf_u5 = (1-eta(i))*(1/DE)*exp5(i,t-1)...
        - (1/DI)/epsilon*inf_u5(i,t-1);
    d_inf_u6 = (1-eta(i))*(1/DE)*exp6(i,t-1)...
        - (1/DI)/epsilon*inf_u6(i,t-1);
    d_inf_u7 = (1-eta(i))*(1/DE)*exp7(i,t-1)...
        - (1/DI)/epsilon*inf_u7(i,t-1);
    d_inf_u8 = (1-eta(i))*(1/DE)*exp8(i,t-1)...
        - (1/DI)/epsilon*inf_u8(i,t-1);
    % susceptible
    d_sus0 = - R00*(1/DI)*sus0(i,t-1)*inf_r(i,t-1)...
            - R00*(1/DI)/epsilon*sus0(i,t-1)*inf_u(i,t-1);
    d_sus1 = - R01*(1/DI)*sus1(i,t-1)*inf_r(i,t-1)...
            - R01*(1/DI)/epsilon*sus1(i,t-1)*inf_u(i,t-1);
    d_sus2 = - R02*(1/DI)*sus2(i,t-1)*inf_r(i,t-1)...
            - R02*(1/DI)/epsilon*sus2(i,t-1)*inf_u(i,t-1);
    d_sus3 = - R03*(1/DI)*sus3(i,t-1)*inf_r(i,t-1)...
            - R03*(1/DI)/epsilon*sus3(i,t-1)*inf_u(i,t-1);
    d_sus4 = - R04*(1/DI)*sus4(i,t-1)*inf_r(i,t-1)...
            - R04*(1/DI)/epsilon*sus4(i,t-1)*inf_u(i,t-1);
    d_sus5 = - R05*(1/DI)*sus5(i,t-1)*inf_r(i,t-1)...
            - R05*(1/DI)/epsilon*sus5(i,t-1)*inf_u(i,t-1);
    d_sus6 = - R06*(1/DI)*sus6(i,t-1)*inf_r(i,t-1)...
            - R06*(1/DI)/epsilon*sus6(i,t-1)*inf_u(i,t-1);
    d_sus7 = - R07*(1/DI)*sus7(i,t-1)*inf_r(i,t-1)...
            - R07*(1/DI)/epsilon*sus7(i,t-1)*inf_u(i,t-1);
    d_sus8 = - R08*(1/DI)*sus8(i,t-1)*inf_r(i,t-1)...
            - R08*(1/DI)/epsilon*sus8(i,t-1)*inf_u(i,t-1);
    % integrate
    exp0(i,t) = exp0(i,t-1)+d_exp0;
    exp1(i,t) = exp1(i,t-1)+d_exp1;
    exp2(i,t) = exp2(i,t-1)+d_exp2;
    exp3(i,t) = exp3(i,t-1)+d_exp3;
    exp4(i,t) = exp4(i,t-1)+d_exp4;
    exp5(i,t) = exp5(i,t-1)+d_exp5;
    exp6(i,t) = exp6(i,t-1)+d_exp6;
    exp7(i,t) = exp7(i,t-1)+d_exp7;
    exp8(i,t) = exp8(i,t-1)+d_exp8;
    exp(i,t) =  exp0(i,t)+exp1(i,t)+exp2(i,t)+exp3(i,t)+exp4(i,t)...
        +exp5(i,t)+exp6(i,t)+exp7(i,t)+exp8(i,t);
    inf_r0(i,t) = inf_r0(i,t-1)+d_inf_r0;
    inf_r1(i,t) = inf_r1(i,t-1)+d_inf_r1;
    inf_r2(i,t) = inf_r2(i,t-1)+d_inf_r2;
    inf_r3(i,t) = inf_r3(i,t-1)+d_inf_r3;
    inf_r4(i,t) = inf_r4(i,t-1)+d_inf_r4;
    inf_r5(i,t) = inf_r5(i,t-1)+d_inf_r5;
    inf_r6(i,t) = inf_r6(i,t-1)+d_inf_r6;
    inf_r7(i,t) = inf_r7(i,t-1)+d_inf_r7;
    inf_r8(i,t) = inf_r8(i,t-1)+d_inf_r8;
    inf_r(i,t) =  inf_r0(i,t)+inf_r1(i,t)+inf_r2(i,t)+inf_r3(i,t)+inf_r4(i,t)...
        +inf_r5(i,t)+inf_r6(i,t)+inf_r7(i,t)+inf_r8(i,t);
    inf_u0(i,t) = inf_u0(i,t-1)+d_inf_u0;
    inf_u1(i,t) = inf_u1(i,t-1)+d_inf_u1;
    inf_u2(i,t) = inf_u2(i,t-1)+d_inf_u2;
    inf_u3(i,t) = inf_u3(i,t-1)+d_inf_u3;
    inf_u4(i,t) = inf_u4(i,t-1)+d_inf_u4;
    inf_u5(i,t) = inf_u5(i,t-1)+d_inf_u5;
    inf_u6(i,t) = inf_u6(i,t-1)+d_inf_u6;
    inf_u7(i,t) = inf_u7(i,t-1)+d_inf_u7;
    inf_u8(i,t) = inf_u8(i,t-1)+d_inf_u8;
    inf_u(i,t) =  inf_u0(i,t)+inf_u1(i,t)+inf_u2(i,t)+inf_u3(i,t)+inf_u4(i,t)...
        +inf_u5(i,t)+inf_u6(i,t)+inf_u7(i,t)+inf_u8(i,t);
    inf0(i,t) = inf_r0(i,t-1)+inf_u0(i,t-1);
    inf1(i,t) = inf_r1(i,t-1)+inf_u1(i,t-1);
    inf2(i,t) = inf_r2(i,t-1)+inf_u2(i,t-1);
    inf3(i,t) = inf_r3(i,t-1)+inf_u3(i,t-1);
    inf4(i,t) = inf_r4(i,t-1)+inf_u4(i,t-1);
    inf5(i,t) = inf_r5(i,t-1)+inf_u5(i,t-1);
    inf6(i,t) = inf_r6(i,t-1)+inf_u6(i,t-1);
    inf7(i,t) = inf_r7(i,t-1)+inf_u7(i,t-1);
    inf8(i,t) = inf_r8(i,t-1)+inf_u8(i,t-1);
    inf(i,t) =  inf0(i,t)+inf1(i,t)+inf2(i,t)+inf3(i,t)+inf4(i,t)...
        +inf5(i,t)+inf6(i,t)+inf7(i,t)+inf8(i,t);
    sus0(i,t) = sus0(i,t-1)+d_sus0;
    sus1(i,t) = sus1(i,t-1)+d_sus1;
    sus2(i,t) = sus2(i,t-1)+d_sus2;
    sus3(i,t) = sus3(i,t-1)+d_sus3;
    sus4(i,t) = sus4(i,t-1)+d_sus4;
    sus5(i,t) = sus5(i,t-1)+d_sus5;
    sus6(i,t) = sus6(i,t-1)+d_sus6;
    sus7(i,t) = sus7(i,t-1)+d_sus7;
    sus8(i,t) = sus8(i,t-1)+d_sus8;
    sus(i,t) =  sus0(i,t)+sus1(i,t)+sus2(i,t)+sus3(i,t)+sus4(i,t)...
         +sus5(i,t)+sus6(i,t)+sus7(i,t)+sus8(i,t);
end
% nation wide calculation
N_array = N*ones(1,T);
INF_R = inf_r.*N_array;
RMSE(x1, x2, x3, :) = mean((INF_R-IA).^2,2).^0.5;
        end
    end
end

state_err = RMSE(:,:,:,outid);
[xmin,ind] = min(state_err(:));
[ii,jj,kk] = ind2sub(size(state_err),ind);
outt(outid,1) = R0_b(outid) - inc_prev + inc_now*ii;
outt(outid,2) = jj*0.1;
outt(outid,3) = kk*0.1;
outt(outid,4) = RMSE(ii,jj,kk,outid);
end